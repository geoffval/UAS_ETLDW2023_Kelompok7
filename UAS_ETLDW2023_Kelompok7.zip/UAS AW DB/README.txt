Notes:
AdventureWorks_OLAP tidak memiliki data.

UAS_ETLDW2023_Kelompok7.bak berupa AdventureWorks_OLAP.bak yang sudah melewati proses ETL dan berisi data.

SQLQuery1.sql berisi code untuk menghapus data supaya proses AdventureWorks_OLAP dapat jalan.

Project ETL terdapat dalam folder AdventureWorks UAS ETL.

Package.dtsx berupa proses ETL untuk tabel dimensi.

Package1.dtsx berupa proses ETL untuk tabel fakta.