DELETE FROM DimBiayaProduksi
DELETE FROM DimDaerah
DELETE FROM DimJenisProduk
DELETE FROM DimPemesanan
DELETE FROM DimPenjualan
DELETE FROM DimProduk
DELETE FROM DimToko
DELETE FROM DimVendor
DELETE FROM DimWaktu
DELETE FROM FactProductionTable
DELETE FROM FactPurchasingTable
DELETE FROM FactSalesTable

Select * from DimPemesanan
